"""
Lycée Saint-André :: TNSI :: Mini-projet KNN/Minecraft
Serveur web pour récolter les données
09/03/2023

Colors of wool
00 => white
01 => orange
02 => magenta
03 => cyan
04 => yellow
05 => green
06 => pink
07 => dark_grey
08 => grey
09 => cyan
10 => violet
11 => blue
12 => brown
13 => dark_green
14 => red
15 => black
"""

# Librairie(s) utilisée(s)
from flask import *
import sqlite3


# Création d'un objet application web Flask
app = Flask(__name__)

# Connexion à la base de données et création d'un curseur
connexion = sqlite3.connect("minecraft_colors.sqlite", check_same_thread=False)
curseur = connexion.cursor()

# Fonctions utilitaires liées à la base de données
def enregistrer_choix(red, green, blue, choice, ip):
    """Enregistre la réponse d'un joueur dans une BDD sqlite3"""

    # Exécution d'une requête SQL UPDATE
    parametres = (red, green, blue, choice, ip)
    resultat = curseur.execute("""
        INSERT INTO Answer (red, green, blue, choice, date, ip)
        VALUES (?, ?, ?, ?, datetime('now'), ?);""",
        parametres
    )    

    # Sauvegarde les changements dans la base de données et se déconnecte
    connexion.commit() 

    # Récupère le nombre de choix dans la bdd
    resultat = curseur.execute("""
        SELECT COUNT(*)
        FROM Answer;"""
    )    
    nb_choices = resultat.fetchone()    

    return nb_choices[0]



# Ajout des fonctions de gestion des routes
@app.route("/")
@app.route("/welcome")
def accueillir():
    """Affiche un message dans le navigateur web"""
    return render_template(
        "welcome.html"
    )

@app.route("/game")
def renseigner():
    """Affiche la page du jeu"""
    return render_template(
        "game.html",
        url_api=f"http://{request.host}/api"
    )

@app.route("/api", methods=["POST"])
def enregistrer():
    """Enregistre le choix du joueur"""
    reponse = request.json
    print(reponse)
    if "red" in reponse.keys() and \
        "green" in reponse.keys() and \
        "blue" in reponse.keys() and \
        "choice" in reponse.keys():
        nb_choices = enregistrer_choix(
            reponse["red"],
            reponse["green"],
            reponse["blue"],
            reponse["choice"],
            request.remote_addr
        )    
    return jsonify({"nb_choices": nb_choices})

@app.route("/csv")
def recuperer_csv():
    """Permet de récupérer un fichier csv"""
    return send_file(
        "static/data/minetest_colors.csv",
        as_attachment=True,
        attachment_filename="minetest_colors.csv"
    )


# Lancement de l'application web et son serveur de test
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1664, debug=True)